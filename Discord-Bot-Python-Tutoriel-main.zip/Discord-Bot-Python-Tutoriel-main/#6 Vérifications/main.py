import discord
from discord.ext import commands
import random

bot = commands.Bot(command_prefix = "U!", description = "Bot de Urania")

@bot.event
async def on_ready():
	print("Ready !")

@bot.command()
@commands.has_permissions(ban_members = True)
async def ban(ctx, user : discord.User, *reason):
	reason = " ".join(reason)
	await ctx.guild.ban(user, reason = reason)
	await ctx.send(f"{user} à été ban pour la raison suivante : {reason}.")

def isOwner(ctx):
	return ctx.message.author.id == 441881039338471425

@bot.command()
@commands.check(isOwner)
async def private(ctx):
	await ctx.send("Cette commande peut seulement etre effectuées par le propriétaire du bot !")

	
bot.run("ODI5NTExNTI2NzY3NTI1OTA4.YG5Mzw.VaOIcNb99o4sN_ggfO7uR7sfMFk")
