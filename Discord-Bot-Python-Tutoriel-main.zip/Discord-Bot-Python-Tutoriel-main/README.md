# Discord-Bot-Python-Tutoriel

Ce repo contient les codes que j'ai a la fin de mes vidéos sur ma chaine youtube (https://www.youtube.com/channel/UChDVo_Uqomuk7KnMVp-Lhhw).
Il contient également les corrections des exercices que je donne a la fin de mes vidéos :)
