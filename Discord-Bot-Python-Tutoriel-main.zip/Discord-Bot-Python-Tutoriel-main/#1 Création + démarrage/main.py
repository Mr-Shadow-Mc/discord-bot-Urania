import discord
from discord.ext import commands

bot = commands.Bot(command_prefix = "U!", description = "Bot de Urania")

@bot.event
async def on_ready():
	print("Ready !")

bot.run("ODI5NTExNTI2NzY3NTI1OTA4.YG5Mzw.VaOIcNb99o4sN_ggfO7uR7sfMFk")
