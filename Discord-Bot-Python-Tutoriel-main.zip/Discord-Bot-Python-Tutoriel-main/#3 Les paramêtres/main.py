import discord
from discord.ext import commands

bot = commands.Bot(command_prefix = "U!", description = "Bot de Urania")

@bot.event
async def on_ready():
	print("Ready !")

@bot.command()
async def say(ctx, *texte):
	await ctx.send(" ".join(texte))

@bot.command()
async def chinese(ctx, *text):
	chineseChar = "丹书匚刀巳下呂廾工丿片乚爪冂口尸Q尺丂丁凵V山乂Y乙"
	chineseText = []
	for word in text:
		for char in word:
			if char.isalpha():
				index = ord(char) - ord("a")
				transformed = chineseChar[index]
				chineseText.append(transformed)
			else:
				chineseText.append(char)
		chineseText.append(" ")
	await ctx.send("".join(chineseText))


bot.run("ODI5NTExNTI2NzY3NTI1OTA4.YG5Mzw.VaOIcNb99o4sN_ggfO7uR7sfMFk")
